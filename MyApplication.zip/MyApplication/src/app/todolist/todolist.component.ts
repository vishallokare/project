import { Component, OnInit } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { UserService } from '../services/user.service';
import { TodoList, User } from '../user/user.model';


@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['../user/user.component.css','./todolist.component.css']
})
export class TodolistComponent implements OnInit {
  $:any;
  currentUser: User;
  addTodoFlag: boolean = false;
  editTodoName : string;
  subscription: Subscription;
  tasksForDelete: any[] = []
  searchtext: string =""
  status: string ='';
  category: string='';
  TodoLists: TodoList[];
  counter=0;
  //faEdit = faEdit
  constructor(private userService: UserService) { }

  ngOnInit(): void {
    
    this.currentUser = this.userService.getUser( sessionStorage.getItem('email'))
    this.subscription = this.userService.taskChanged
            .subscribe((todo: TodoList[]) => {
              this.currentUser.todoList = todo
             });
             this.TodoLists=this.currentUser.todoList ;

  }

  openModal(){
    this.editTodoName = ''
    console.log('todoList->openModal->editTodoName=' + this.editTodoName);
    this.addTodoFlag = true
  }

  openModalForEdit(todoName:string){
    this.editTodoName= todoName;
    console.log('todoList->openModalForEdit->editTodoName=' + this.editTodoName);
    this.addTodoFlag = true
  }

  addtodofordelete(event: any, taskName:string){
    
    if(event.target.checked && !this.tasksForDelete.includes(taskName)){
      this.tasksForDelete.push(taskName)
    }else{
      this.tasksForDelete.splice(this.tasksForDelete.indexOf(taskName),1)
    }
  }

deleteSelectedTodos(){


  if(this.tasksForDelete.length > 0) {
    this.userService.deleteTasks(this.tasksForDelete)
  }
  this.tasksForDelete = [];
  this. ngOnInit();
  alert("Selected Record deleted Successfully !!!");
}



}
