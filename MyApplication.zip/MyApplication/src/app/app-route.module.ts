import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth/auth.service';
import { TodolistComponent } from './todolist/todolist.component';
import { ProfileEditComponent } from './user/profile/profile-edit/profile-edit.component';
import { LoginComponent } from './user/Login/login.component';
import { RegisterComponent } from './user/register/register.component';

const routes: Routes = [
    {
        path:'',
        redirectTo: '/user/signin',
        pathMatch: 'full'
    },
    {
        path:'user/signin',
        component: LoginComponent
    },
    {
        path:'user/signup',
        component: RegisterComponent
    },
    {
        path:'todolist',
        component: TodolistComponent,
        canActivate: [AuthGuard]
    },
    {
        path:'user/editprofile',
        component: ProfileEditComponent,
        canActivate: [AuthGuard]
    }
]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRouteModule { }